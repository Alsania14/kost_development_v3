<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kamarimage extends Model
{
    //
}
