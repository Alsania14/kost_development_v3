<?php

namespace App\Http\Controllers\admindashboard\reportuser;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

use App\Transaksi;

class ValidasiController extends Controller
{
    public function index()
    {
        // MENGAMBIL DATA TRANSAKSI MANUAL
            $transaksis = DB::table('tagihans')
                            ->select('transaksis.*' ,'users.username','tagihans.nomor_kamar','tagihans.tipe_pembayaran','tagihans.nominal_pembayaran')
                            ->join('transaksis','transaksis.tagihan_id','=','tagihans.id')
                            ->join('users','users.id','=','tagihans.user_id')
                            ->where('transaksis.via','manual')
                            ->where('tagihans.status_tagihan','hutang')
                            ->where('transaksis.deleted_by_admin',0)
                            ->paginate(10);
        // AKHIR
        
        
        // MENGAMBIL DATA ADMIN
            $admin = Auth::user();
        // AKHIR
    
        // CEK NOTIFIKASI USER
            $notification = $admin->unreadNotifications->count();
            if($notification == 0)
            {
                $notification = null;
            }
        // AKHIR

        return view('admin\adminreportuser\validasitransaksi\validasitransaksi',compact('transaksis','notification'));

    }
}
