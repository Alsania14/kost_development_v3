
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('wifi',config('global.active')); ?>
<?php $__env->startSection('header','Wifi'); ?>
<?php $__env->startSection('content'); ?>
<!-- AWAL CONTAINER -->
<div class="container-fluid p-0" style="min-height:600px;">
    <div class="row">
        <div class="col">
            <div class="jumbotron bg-dark" style="border-top:3px solid orange;height:500px;">
                <div class="h2 text-center">WIFI NAME</div>

                <div class="d-flex justify-content-center">
                <label class="bg-light text-dark w-25 font-weight-bold lead text-center" style="min-width:200px;border-top:3px solid orange;border-radius:5px;">
                    <?php echo e($wifi); ?>

                </label>
                </div>

                <div class="h2 text-center mt-5">WIFI PASSWORD</div>
                <div class="d-flex justify-content-center">
                <label class="bg-light text-dark w-25 font-weight-bold lead text-center" style="min-width:200px;border-top:3px solid orange;border-radius:5px;">
                    <?php echo e($password); ?>

                </label>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- AKHIR CONTAINER -->
<footer class="page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>

<?php $__env->startSection('judul','UPDATE BERHASIL'); ?>
<?php $__env->startSection('isi','Update berhasil,Pastikan anda memberikan identitas dan dokumen yang valid, apabila anda melakukan perbuhan pada email mohon untuk melakukan verifikasi kembali'); ?>



<?php $__env->startSection('modal_denied_judul','VERIFIKASI EMAIL'); ?>
<?php $__env->startSection('modal_denied_isi','EMAIL VERIFIKASI TELAH DIKIRIMKAN KE EMAIL ANDA MOHON UNTUK MEMBUKA EMAIL ANDA DAN MENEKAN LINK YANG DIBERIKAN'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal_denied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/user/wifi/wifi.blade.php ENDPATH**/ ?>