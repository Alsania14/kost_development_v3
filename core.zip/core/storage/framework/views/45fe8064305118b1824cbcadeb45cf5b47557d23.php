
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('profile',config('global.active')); ?>
<?php $__env->startSection('header','Profile'); ?>
<?php $__env->startSection('content'); ?>

<!-- AWAL CONTAINER -->
<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="col-md-7 d-flex justify-content-center">
            <img src="<?php echo e(url('storage/image_users',[$user->image])); ?>" alt="Something wrong" style="width:200px;height:200px;border-radius:50%;" class="img-thumbnail">
        </div>
    </div>

    <div class="row d-flex justify-content-center mt-2">
        <div class="col-md-7 d-flex justify-content-center h3 text-center">
            <?php echo e($user->name); ?>

        </div>
    </div>

    <div class="row d-flex justify-content-center mt-2">
        <div class="col-md-7 d-flex justify-content-center h5 text-center">
            <?php echo e(strtoupper($user->username)); ?>

        </div>
    </div>

    <div class="row d-flex justify-content-center mt-5">
        <div class="col-md-6 d-flex justify-content-between border-bottom">
            <div>
                Email
            </div>
            <div>
                <?php echo e($user->email); ?>

            </div>
        </div>
    </div>

    <div class="row d-flex justify-content-center">
        <div class="col-md-6 d-flex justify-content-between border-bottom">
            <div>
                Nomor HP
            </div>
            <div>
                <?php
                    // JIKA NULL
                        if($user->nomor_hp == null)
                        {
                            echo 'Belum Diatur';
                        }
                        else
                        {
                            echo $user->nomor_hp;
                        }
                    // AKHIR
                ?>
            </div>
        </div>
    </div>

    <div class="row d-flex justify-content-center">
        <div class="col-md-6 d-flex justify-content-between border-bottom">
            <div>
                KTP
            </div>
            <div>
                <?php
                    // JIKA NULL
                    if($user->ktp == 'ktp_default.jpg')
                    {
                        echo 'Belum Diatur';
                    }
                    else
                    {
                        echo '<a href="'.url('/storage/ktp_users/',[$user->ktp]).'"><button class="badge badge-info">Lihat</button></a>';
                    }
                ?>
            </div>
        </div>
    </div>

    <div class="row d-flex justify-content-center">
        <div class="col-md-6 d-flex justify-content-between border-bottom">
            <div>
                Room
            </div>
            <div>
                <?php echo e($kamar->nomor); ?>

            </div>
        </div>
    </div>

    <div class="row d-flex justify-content-center">
        <div class="col-md-6 d-flex justify-content-between border-bottom">
            <div>
                Tanggal Masuk
            </div>
            <div>
                <?php echo e($user->created_at); ?>

            </div>
        </div>
    </div>

    <div class="row d-flex justify-content-center pt-5 mb-5">
        <div class="col-md-6 d-flex justify-content-center">
            <a href="<?php echo e(url('/edit',[Crypt::encryptString($user->id)])); ?>">
            <button class="btn" style="<?php echo e(config('global.active')); ?>">Edit Profile</button>
            </a>
        </div>
    </div>

</div>
<!-- AKHIR CONTAINER -->

<?php $__env->startSection('judul','UPDATE BERHASIL'); ?>
<?php $__env->startSection('isi','Update berhasil,Pastikan anda memberikan identitas dan dokumen yang valid'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views//user/profile/profile.blade.php ENDPATH**/ ?>