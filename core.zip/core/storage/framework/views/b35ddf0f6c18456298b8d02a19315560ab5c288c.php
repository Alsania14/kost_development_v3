
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('kamar',config('global.active')); ?>
<?php $__env->startSection('header','Kamar / Gambar Kamar'); ?>
<?php $__env->startSection('content'); ?>

<!-- AWAL CONTAINER -->
<div class="container-fluid p-0">
<div class="row m-0 mb-3 justify-content-end">
    <div class="btn-group" role="group" aria-label="Basic example">
      <a href="<?php echo e(url('/kamar')); ?>" type="button" class="btn btn-primary">Kembali</a>
    </div>
  </div>
    <div class="row">
        <div class="col">
            <div class="jumbotron m-0 text-center bg-dark d-flex justify-content-center flex-column" style="border-top: 3px solid orange;">
            <h3 class="mb-4">GAMBAR KAMAR <?php echo e($kamar_single->nomor); ?></h3>
            <div class="container d-flex justify-content-center flex-wrap">
<?php
            foreach ($gambars as $key)
            {
?>
            <a href="<?php echo e(url('storage/kamar',[$key->image])); ?>">
            <img src="<?php echo e(url('storage/kamar',[$key->image])); ?>" class="m-1 img-thumbnail" alt="Ops Something Wrong" style="max-height:300px;">
            </a>
<?php
            }
?>
            </div>
            </div>
        </div>
    </div>    
</div>
<!-- AKHIR CONTAINER -->
<footer class="page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/user/kamar/gambarkamar.blade.php ENDPATH**/ ?>