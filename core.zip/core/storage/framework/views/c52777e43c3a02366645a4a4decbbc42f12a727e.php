
<?php $__env->startSection('content'); ?>
<h4>SUBJECT : LAPORAN KELUHAN KERUSAKAN PROPERTI</h4>
<h4>Hai Admin,</h4>
<p>Berikut ini merupakan keluhan kerusakan properti yang dikirimkan oleh user kost. Berikut sistem berikan informasinya</p>
<p>PENGIRIM : <?php echo e($data['name']); ?> <br></p>
<p>KAMAR : <?php echo e($data['kamar']); ?> <br></p>
<p>KELUHAN : <br></p>
<p><?php echo e($data['keluhan']); ?></p>

<a href="<?php echo e(url('storage/image_pelaporan',[$data['image']])); ?>">
<img src="<?php echo e(url('storage/image_pelaporan',[$data['image']])); ?>" alt="LAPORAN TIDAK DISERTAKAN GAMBAR" style="max-height:200px;">
</a>
<p>KLIK GAMBAR UNTUK PERBESAR</p>

<p>Sekian saja laporan dari sistem, mohon untuk segera dibalas laporan dari user, saat admin membalas sistem akan mengirimkan email ke user secara real time</p>

<p><b>BIG REGRADS</b></p><br><br>
<p><b>THE SYSTEM</b></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('email/email_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/email/LaporanAdmin.blade.php ENDPATH**/ ?>