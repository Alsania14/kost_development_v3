
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('pembayaran',config('global.active')); ?>
<?php $__env->startSection('header','Pembayaran Kost \ Transaksi'); ?>
<?php $__env->startSection('content'); ?>
<!-- AWAL CONTAINER -->
<div class="container-fluid p-0" style="min-height:550px;">
  <div class="row m-0 justify-content-end">
    <div class="btn-group" role="group" aria-label="Basic example">
      <a href="<?php echo e(url('/dashboard')); ?>" type="button" class="btn btn-primary">Kembali</a>
      <a href="<?php echo e(url('/arsiptransaksi')); ?>" type="button" class="btn btn-primary">Lihat Arsip</a>
    </div>
  </div>
<p class="text-info mt-1">Hai <?php echo e($user->username); ?>, Halaman ini memuat semua transaksi anda</p>
      <div class="table-responsive">
      <table class="table table-striped table-sm text-light" style="border-bottom:3px solid #e39414">
          <thead style="<?php echo e(config('global.active')); ?>">
            <tr>
              <th>Nomor</th>
              <th>Order ID</th>
              <th>Metode</th>
              <th>Total</th>
              <th>Status Transaksi</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
<?php
                foreach ($transaksis as $index => $transaksi) {
?>
                 <tr>
                    <td><?php echo e(($index+1)); ?></td>
                    <td style="min-width:200px;"><?php echo e($transaksi->order_id); ?></td>
                    <td><?php echo e(strtoupper($transaksi->integration_name)); ?></td>
                    <td style="min-width:150px;"><?php echo e('Rp. '.number_format($transaksi->nominal,0,'.','.')); ?></td>
                    <td><?php echo e(strtoupper($transaksi->status_pembayaran)); ?></td>
                    <td>

<?php 
                      $encrypt = Crypt::encryptString($transaksi->id);
                      if($transaksi->via == 'bank_transfer')
                      {
?>

                        <a href="<?php echo e(url('/bank_transfer',[$encrypt])); ?>">
                          <button class="btn-sm btn-info" style="display:inline-block;">Detail Bank Transfer</button>
                        </a>
<?php
                      }
                      elseif($transaksi->via == 'kedai')
                      {
?>
                        <a href="<?php echo e(url('/kedai',[$encrypt])); ?>">
                          <button class="btn-sm btn-info" style="display:inline-block;">Detail Toko Transfer</button>
                        </a>
<?php
                      }
                      elseif($transaksi->via == 'manual')
                      {
?>
                        <a href="<?php echo e(url('/manual',[$encrypt])); ?>">
                          <button class="btn-sm btn-info" style="display:inline-block;">Detail Manual Transfer</button>
                        </a>
<?php
                      }
?>
                        <form action="<?php echo e(url('/refresh',[$encrypt])); ?>" class="m-0" style="display:inline-block;" method="POST">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(method_field('PUT')); ?>

<?php
                            if($transaksi->status_pembayaran == 'approved')
                            {
?>
                                  <input class="btn-sm btn-secondary" type="submit" value="Refresh" disabled>
<?php
                            }
                            else
                            {
?>
                                  <input class="btn-sm btn-primary" type="submit" value="Refresh">
<?php
                            }
?>
                          </form>
                          <form action="<?php echo e(url('/arsiptransaksi',[$encrypt])); ?>" class="m-0" style="display:inline-block;" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('put')); ?>

                            <input class="btn-sm btn-danger" type="submit" value="Arsip">
                          </form>                    
                    </td>
                 </tr>   
<?php
                }
?>
          </tbody>
        </table>
        </div>

</div>
<!--  AKHIR CONTAINER -- -->
<footer class="row page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>

<?php $__env->startSection('judul','Refresh Berhasil'); ?>
<?php $__env->startSection('isi','Refresh Berhasil !'); ?>


<?php $__env->startSection('modal_denied_judul','Refresh Gagal'); ?>
<?php $__env->startSection('modal_denied_isi','Mohon Maaf Refresh gagal, kemungkinan sedang terjadi gangguan atau masalah jaringan, Silahkan buat charge baru atau laporkan kepada developer'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal_denied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views//user/pembayaran/transaksi/transaksi.blade.php ENDPATH**/ ?>