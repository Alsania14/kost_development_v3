
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('pembayaran',config('global.active')); ?>
<?php $__env->startSection('header','Pembayaran Kost \ Tagihan Anda \ Pilih Pembayaran \ Charge Success'); ?>
<?php $__env->startSection('content'); ?>
<!-- AWAL CONTAINER -->
<div class="container-fluid p-0" style="min-height:550px;">

    <div class="jumbotron bg-dark pt-4" style="border-top:3px solid orange;">
    <h1 class="display-4 mb-5">Charge Success</h1>
    <span style="font-family:courier new;">
    <p class="lead border-top border-bottom text-center">
       ONLINE VIRTUAL ACCOUNT PAYMENT</p>
    <p style="font-size:20pt;">
    <b>SUBJECT NOTA</b><br>
    ORDER ID : <br> <?php echo e($transaksi->order_id); ?> <br><br>
    DATE : <br> <?php echo e($transaksi->created_at); ?> <br><br>
    DIBERIKAN UNTUK : <br> <?php echo e($user->name); ?> <br><br>

    <b>PAYMENT METHOD</b><br>
    MANUAL PAYMENT : <br> <?php echo e($transaksi->integration_name); ?> <br><br>

    <b>RANGKUMAN PEMBAYARAN</b><br>
    KAMAR NOMOR <?php echo e($nomor); ?> <br> QTY 1 <br> TANGGAL SEWA <br> <?php echo e($transaksi->tgl_awal); ?> S/D <?php echo e($transaksi->tgl_akir); ?> <br>
    HARGA <?php echo e('Rp. '.number_format($transaksi->nominal,0,'.','.')); ?>

    <br><br>
    TOTAL <?php echo e('Rp. '.number_format($transaksi->nominal,0,'.','.')); ?> <br><br>

    <div class="border-bottom justify-content-center" style="overflow:hidden;">
        <p style="font-size:20pt;"><b>BUKTI PEMBAYARAN  :</p> </b>
        <div class="w-100 d-flex justify-content-center">
<?php
            if($transaksi->bukti_transaksi == null && $transaksi->status_pembayaran != 'approved')
            {
?>
            <img src="<?php echo e(url('storage/bukti_pembayaran/noimage.png')); ?>" alt="belum ada bukti pembayaran" style="max-width:300px;" id="img_bukti">
            </div>
            
                <form action="<?php echo e(url('/uploadbukti')); ?>" method="post" enctype="multipart/form-data" class="d-flex justify-content-center flex-wrap">
                    <?php echo e(csrf_field()); ?>

                    <label for="inputan" class="btn-sm mt-3 btn-light">Select Image</label>
                    <input class="btn-sm text-light w-100" style="visibility:hidden;" type="file" name="bukti" onchange="ganti()" accept="image/*" id="inputan" required>
                    <input type="hidden" name="tagihan" value="<?php echo e($id); ?>">
                    <input class="btn-light btn-sm text-dark mt-3" type="submit" value="kirim" style="max-height:30px;">
                </form>
        
<?php       }
            elseif($transaksi->bukti_transaksi != null && $transaksi->status_pembayaran == 'pending')
            {
?>          
            <a href="<?php echo e(url('storage/bukti_pembayaran',[$transaksi->bukti_transaksi])); ?>">
            <img src="<?php echo e(url('storage/bukti_pembayaran',[$transaksi->bukti_transaksi])); ?>" alt="belum ada bukti pembayaran" style="max-width:300px;" id="img_bukti"></a>
            </div>
        
            <form action="<?php echo e(url('/uploadbukti')); ?>" method="post" enctype="multipart/form-data" class="d-flex justify-content-center flex-wrap">
                <?php echo e(csrf_field()); ?>

                <label for="inputan" class="btn-sm mt-3 btn-light">Ganti Gambar Bukti</label>
                <input class="btn-sm text-light w-100" style="visibility:hidden;" type="file" name="bukti" onchange="ganti()" accept="image/*" id="inputan" required>
                <input type="hidden" name="tagihan" value="<?php echo e($id); ?>">
                <input class="btn-light btn-sm text-dark mt-3" type="submit" value="kirim Ulang" style="max-height:30px;">
            </form>
<?php
            }
            elseif($transaksi->bukti_transaksi != null && $transaksi->status_pembayaran == 'approved')
            {
?>
            <a href="<?php echo e(url('storage/bukti_pembayaran',[$transaksi->bukti_transaksi])); ?>">
            <img src="<?php echo e(url('storage/bukti_pembayaran',[$transaksi->bukti_transaksi])); ?>" alt="belum ada bukti pembayaran" style="max-width:300px;" id="img_bukti"></a>
            <p class="position-absolute h1" style="left:50%px;font-weight:1000; border-top:5px solid green;color:green;border-bottom:5px solid green;margin-top:150px;">APPROVED</p>
            </div>
            <div class="w-100 mt-5 mb-5 text-center">
            <input type="submit" class="bg-success" value="APPROVED BY ADMIN" disabled>
            </div>
<?php
            }
            elseif($transaksi->status_pembayaran == 'expired')
            {
?>         
            <p class="position-absolute text-danger h1" style="left:50%px;font-weight:bold;">EXPIRED</p>
            </div>
            <div class="w-100 mt-5 mb-5 text-center">
            <p>Anda tidak mengupload bukti pembayaran hingga pukul 00.00 malam. Tolong ulangi proses charge pembayaran dan upload bukti setelahnya</p>
            <input type="submit" class="bg-danger" value="EXPIRED" disabled>
            </div>
<?php
            }
            elseif($transaksi->status_pembayaran == 'rejected')
            {
?>
             <p class="position-absolute text-danger h1" style="left:50%px;font-weight:bold;">REJECTED</p>
            </div>
            <div class="w-100 mt-5 mb-5 text-center">
            <p>Dimohon untuk melakukan pembayaran secara valid dan sesuai dengan arahan yang diberikan. tolong hubungi admin jika terjadi masalah teknis</p>
            <input type="submit" class="bg-danger" value="REJECTED" disabled>
            </div>
<?php
            }
?>  
    </div>
    </p>
    <hr class="my-4">
    </span>
    <p class="text-light">Charge pembayaran kost secara manual berhasil dilakukan tolong untuk segera mengupload (mengunggah) bukti pembayaran anda. Setelah mengirim, selama belum diverifikasi oleh admin anda bebas untuk mengganti foto yang telah dikirim melalui halaman ini</p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="<?php echo e(url('/transaksi')); ?>" role="button">Halaman Transaksi</a>
    </p>
    </div>

</div>
<!--  AKHIR CONTAINER -- -->
<footer class="row page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>

<script>
    var img = document.getElementById("img_bukti");
    var input = document.getElementById("inputan");
    function ganti()
    {
        img.src = window.URL.createObjectURL(input.files[0]);
    }
</script>



<?php $__env->startSection('judul','Berhasil'); ?>
<?php $__env->startSection('isi','Silahkan Lanjutkan ke langkah selanjutnya'); ?>


<?php $__env->startSection('modal_denied_judul','Upload bukti gagal'); ?>
<?php $__env->startSection('modal_denied_isi','Format salah atau ukuran gambar terlalu besar'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal_denied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views//user/pembayaran/transaksi/detailmanual.blade.php ENDPATH**/ ?>