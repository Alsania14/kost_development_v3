
<?php $__env->startSection('reportadmin',config('global.active')); ?>
<?php $__env->startSection('header','Tagihan Users / Transaksi'); ?>
<?php $__env->startSection('jumlah',$notification); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
    <div class="row mb-4 mr-1 justify-content-end">
    <div class="btn-group" role="group" aria-label="Basic example">
      <a href="<?php echo e(url()->previous()); ?>" type="button" class="btn btn-primary">Kembali</a>
    </div>
    </div>
  
    <div class="jumbotron bg-dark p-0" id="searchengine" style="border-top:3px solid orange;overflow:hidden;">
    <div class="row">
        <div class="col-md mt-4">
            <h3 class="text-center">TRANSAKSI TAGIHAN</h3>
            <p class="text-center text-info">Satu tagihan dapat memiliki lebih dari satu transaksi, sesuai dengan jumlah <b class="text-info">CHARGE</b> yang dilakukan user</p>
        </div>
    </div>

    <div class="row m-0 ml-3">
        <table>
            <tr>
                <th style="min-width:160px;">TRANSAKSI TAGIHAN</th>
                <td>: <?php echo e($tagihan->user()->username); ?></td>
            </tr>
            <tr>
                <th>BANYAK CHARGE</th>
                <td>: <?php echo e($transaksis->count()); ?></td>
            </tr>
            <tr>
                <th>PEMBAYARAN KAMAR</th>
                <td>: NOMOR <?php echo e($tagihan->nomor_kamar); ?></td>
            </tr>
            <tr>
                <th>TANGGAL AWAL SEWA</th>
                <td>: <?php echo e($tagihan->tgl_awal_sewa); ?></td>
            </tr>
            <tr>
                <th>TANGGAL AKHIR SEWA</th>
                <td>: <?php echo e($tagihan->tgl_akhir_sewa); ?> </td>
            </tr>
            <tr>
                <th>TIPE</th>
                <td>: <?php echo e(strtoupper($tagihan->tipe_pembayaran)); ?> </td>
            </tr>
            <tr>
                <th>NOMINAL TAGIHAN</th>
                <td>: Rp. <?php echo e(number_format($tagihan->nominal_pembayaran,0,'.','.')); ?></td>
            </tr>
        </table>
    </div>

    <div class="row p-3">
        <div class="col-md mt-4">
            <div class="table-responsive">
            <table class="table table-striped table-sm text-light" style="border-bottom:3px solid #e39414">
                <thead style="<?php echo e(config('global.active')); ?>">
                <tr>
                <th>Nomor</th>
                <th style="min-width:200px;">Order ID</th>
                <th style="min-width:100px;">Methode</th>
                <th style="min-width:100px;">Bukti Transaksi</th>
                <th style="min-width:100px;">VA CODE</th>
                <th style="min-width:100px;">BILL CODE</th>
                <th style="min-width:100px;">Status Pembayaran</th>
                <th style="min-width:200px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
<?php
                foreach ($transaksis as $index => $transaksi)
                {
                $id=Crypt::encryptString($transaksi->id);
?>
                    <tr>
                        <td><?php echo e(($index+1)); ?></td>
                        <td><?php echo e($transaksi->order_id); ?></td>
                        <td><?php echo e($transaksi->integration_name); ?></td>
<?php
                    if($transaksi->bukti_transaksi != null)
                    {
?>
                        <td><a class="btn btn-info btn-sm" href="<?php echo e(url('storage/bukti_pembayaran',[$transaksi->bukti_transaksi])); ?>">LIHAT BUKTI</a></td>
<?php

                    }
                    else
                    {
?>
                        <td></td>
<?php
                    }
?>
                        <td><?php echo e($transaksi->field_1); ?></td>
                        <td><?php echo e($transaksi->field_2); ?></td>
                        <td><?php echo e($transaksi->status_pembayaran); ?></td>
                        <td>
<?php
                        if($transaksi->status_pembayaran != "approved" && $transaksi->status_pembayaran != "rejected" && $transaksi->status_pembayaran != "expired")
                        {
?>
                        <label class="btn btn-sm btn-danger" onclick="peringatan(<?php echo e($index); ?>)">REJECT</label>
                        <form action="<?php echo e(url('/adminrejecttransaksi',[$id])); ?>" style="display:none;" method="POST" id="form_<?php echo e($index); ?>">
                            <?php echo e(csrf_field()); ?>

                        </form>
                        </td>
<?php
                        }
                        else
                        {
?>
                        <a class="btn btn-sm bg-secondary">REJECT</a>
<?php
                        }
?>
                    </tr>
<?php
                }
?>
            </tbody>

            </table>
            </div>
        
        </div>
    </div>

    
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('judul','PERINGATAN ADMIN'); ?>
<?php $__env->startSection('isi'); ?>
<p class="text-dark"><b class="text-dark">SALAM ADMIN,</b> <br> Berikut ini merupakan peringatan efek apa yang akan terjadi pada sistem apabila admin melakukan reject charge transaksi.</p>
    <ul>
        <li class="text-dark"><b class="text-dark">CHARGE TRANSAKSI</b> yang telah ditarik tidak dapat dikembalikan</li>
        <li class="text-dark">Sistem akan merequest pembatalan transaksi ke midtrans apabila menggunakan <b class="text-dark">CHARGE TRANSAKSI</b> menggunakan integrasi midtrans</li>
        <li class="text-dark"><b class="text-dark">CHARGE TRANSAKSI MANUAL</b> akan langsung dibatalkan tanpa perlu request ke midtrans</li>
        <li class="text-dark">User tidak dapat melanjutkan <b class="text-dark">CHARGE TRANSAKSI</b> yang dibatalkan</li>
        <li class="text-dark">Lapor bila mendapatkan BUG</li>
    </ul>
<p class="text-dark"><b class="text-dark">TERIMAKASI ADMIN,</b> <br> Demi keamanan, untuk melanjutkan tindakan ini admin diharuskan memasukkan password aktif admin</p>
    <div class="d-flex flex-column">
    <h5 class="text-bold text-dark">PASSWORD</h5>
    <input type="password" class="form-controll text-dark" id="modal_lanjutkan_1" placeholder="PASSWORD ADMIN" form="" name="password" required>
    <input type="submit" id="modal_lanjutkan_2" class="btn-info btn mt-3" value="LANJUTKAN" style="position:relative;transform:translateX(-50%);left:50%;" form="">
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal_denied_judul','GAGAL'); ?>
<?php $__env->startSection('modal_denied_isi'); ?>
                pastikdan admin memberikan password aktif yang benar, dan juga status CHARGE TRANSAKSI belum dibayar oleh user
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tambahanbawah'); ?>
<script>
    function peringatan(index)
    {   
        console.log('form_'+index);
        $('#modal_lanjutkan_1').attr('form', 'form_'+index);
        $('#modal_lanjutkan_2').attr('form', 'form_'+index);
        $('#modal').modal('show');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal_denied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout.admindashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/admin/adminreportuser/tagihanuser/admintagihantransaksi.blade.php ENDPATH**/ ?>