
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('pembayaran',config('global.active')); ?>
<?php $__env->startSection('header','Pembayaran Kost \ Tagihan Anda \ Pilih Pembayaran'); ?>
<?php $__env->startSection('content'); ?>
<!-- AWAL CONTAINER -->
<div class="container-fluid p-0" style="min-height:550px;">
    
    <div class="container-fluid pb-3 m-0 text-center">
        <div class="h4 pt-3">ONLINE PAYMENT</div>
        
        <div class="row">
        <div class="col-sm-3 mt-4 d-flex justify-content-center">
            <div class="card" style="max-width:300px;background: rgb(1,94,109);background: linear-gradient(90deg, rgba(1,94,109,1) 11%, rgba(40,179,201,1) 100%);">
            <img class="card-img-top" src="<?php echo e(asset('vendor_app\img_web\BNI.jpg')); ?>" alt="Card image cap" style="height:150px;" >
            <div class="card-body">
                <h5 class="card-title">BANK BNI</h5>
                <p class="card-text">Pembayaran menggunakan Virtual Account Bank BNI, Transaksi akan langsung terdeteksi sistem tanpa menunggu verifikasi admin</p>
                <form action="<?php echo e(url('/onlinebni')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="tagihan" value="<?php echo e($id); ?>">
                <input type="submit" class="btn mt-2 font-weight-bold" value="CHARGE" style="<?php echo e(config('global.active')); ?>">
                </form>
            </div>
            </div>
        </div>
        <div class="col-sm-3 mt-4 d-flex justify-content-center">
            <div class="card" style="max-width:300px;background: rgb(1,4,255);background: linear-gradient(90deg, rgba(1,4,255,1) 0%, rgba(64,66,255,1) 100%);">
            <img class="card-img-top" src="<?php echo e(asset('vendor_app\img_web\BCA.jpg')); ?>" alt="Card image cap" style="height:150px;">
            <div class="card-body">
                <h5 class="card-title">BANK BCA</h5>
                <p class="card-text">Pembayaran Menggunakan Virtual Account BCA, transaksi akan langsung terdeteksi sistem tanpa memerlukan verifikasi admin</p>
                <form action="<?php echo e(url('/onlinebca')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="tagihan" value="<?php echo e($id); ?>">
                 <input type="submit" class="btn mt-2 font-weight-bold" value="CHARGE" style="<?php echo e(config('global.active')); ?>">
                </form>
            </div>
            </div>
        </div>
        <div class="col-sm-3 mt-4 d-flex justify-content-center">
            <div class="card" style="max-width:300px;background:#1d2f61;">
            <img class="card-img-top" src="<?php echo e(asset('vendor_app\img_web\MANDIRI.png')); ?>" alt="Card image cap" style="height:150px;">
            <div class="card-body">
                <h5 class="card-title">BANK MANDIRI</h5>
                <p class="card-text">Pembayaran menggunakan Billing Code dan Bill Key Bank Mandiri. Transaksi akan langsung terdeteksi tanpa verifikasi admin</p>
                <form action="<?php echo e(url('/onlinemandiri')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="tagihan" value="<?php echo e($id); ?>">
                 <input type="submit" class="btn mt-2 font-weight-bold" value="CHARGE" style="<?php echo e(config('global.active')); ?>">
                </form>
            </div>
            </div>
        </div>
        <div class="col-sm-3 mt-4 d-flex justify-content-center">
            <div class="card " style="max-width:300px;background:#c23917;">
            <img class="card-img-top" src="<?php echo e(asset('vendor_app\img_web\PERMATA.png')); ?>" alt="Card image cap" style="height:150px;">
            <div class="card-body">
                <h5 class="card-title">BANK PERMATA</h5>
                <p class="card-text">Pempabayaran menggunakan Virtual Account Bank Permata yang akan langsung terdeteksi sistem tanpa perlu verifikasi admin</p>
                <form action="<?php echo e(url('/onlinepermata')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="tagihan" value="<?php echo e($id); ?>">
                 <input type="submit" class="btn mt-2 font-weight-bold" value="CHARGE" style="<?php echo e(config('global.active')); ?>">
                </form>
            </div>
            </div>
        </div>

        
        </div>
        
    </div>


    <div class="container-fluid pb-3 m-0 text-center mt-5" style="border-top:3px solid orange;border-bottom:3px solid orange;">
        <div class="h4 pt-3">ONLINE PAYMENT</div>
        
        <div class="row">
        <div class="col-sm mt-2 d-flex justify-content-center">
            <div class="card" style="max-width:300px;<?php echo e(config('global.active')); ?>">
            <img class="card-img-top" src="<?php echo e(asset('vendor_app\img_web\img3.jpg')); ?>" alt="Card image cap" >
            <div class="card-body">
                <h5 class="card-title">BANK BNI</h5>
                <p class="card-text">Pembayaran menggunakan Virtual Account Bank BNI, Transaksi akan langsung terdeteksi sistem tanpa menunggu verifikasi admin</p>
                <form action="#" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="metode" value="online">
                <input type="hidden" name="bank" value="permata">
                <input type="submit" class="btn btn-secondary mt-2" value="CHARGE">
                </form>
            </div>
            </div>
        </div>
        <div class="col-sm mt-2 d-flex justify-content-center">
            <div class="card bg-dark " style="max-width:300px;<?php echo e(config('global.active')); ?>">
            <img class="card-img-top" src="<?php echo e(asset('vendor_app\img_web\img2.jpg')); ?>" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">BANK BCA</h5>
                <p class="card-text">Pembayaran Menggunakan Virtual Account BCA, transaksi akan langsung terdeteksi sistem tanpa memerlukan verifikasi admin</p>
                <form action="#" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="metode" value="online">
                <input type="hidden" name="bank" value="permata">
                <input type="submit" class="btn btn-secondary mt-2" value="CHARGE">
                </form>
            </div>
            </div>
        </div>
    

        
        </div>
        
    </div>


</div>
<!--  AKHIR CONTAINER -- -->
<footer class="row page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/user/pembayaran/tagihan/pilih_pembayaran.blade.php ENDPATH**/ ?>