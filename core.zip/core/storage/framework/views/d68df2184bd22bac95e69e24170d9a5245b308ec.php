<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Sparsh Architecture</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300i,400,500" rel="stylesheet">

	<link rel="stylesheet" href="<?php echo e(asset('vendor_app/sprash/vendor/themify-icons/themify-icons.css')); ?>">
	<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
	<link rel="stylesheet" href="<?php echo e(asset('vendor_app/sprash/vendor/owl-carousel/owl.theme.default.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor_app/sprash/vendor/owl-carousel/owl.carousel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor_app/sprash/vendor/bootstrap/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor_app/sprash/css/style.css')); ?>">
</head>
<body>
	<!-- ================Offcanvus Menu Area =================-->
	<div class="side_menu">
			<ul class="list menu_right">
				<li>
					<a href="<?php echo e(url('/')); ?>">Home</a>
				</li>
				<li>
					<a href="<?php echo e(url('/login')); ?>">Login</a>
				</li>
				<li>
					<a href="<?php echo e(url('/register')); ?>">Register</a>
				</li>
				<li>
					<a href="<?php echo e(url('/developer')); ?>">Developer</a>
				</li>
			</ul>
	</div>
	<!--================End Offcanvus Menu Area =================-->

	<!--================Canvus Menu Area =================-->
	<div class="canvus_menu">
		<div class="container">
			<div class="float-right">
				<div class="toggle_icon" title="Menu Bar">
					<span></span>
				</div>
			</div>
		</div>
	</div>
	<!--================End Canvus Menu Area =================-->
  <header>
    <div class="hero">
      <a class="navbar-brand" href="index.html">
        <img src="<?php echo e(asset('vendor_app/sprash/img/logo.png')); ?>" alt="">
      </a>
      
      <div class="owl-carousel owl-theme heroCarousel">
        <div class="item">
          <div class="hero__slide">
            <img src="<?php echo e(asset('vendor_app/sprash/img/hero-2.png')); ?>" alt="">
            <div class="hero__slideContent text-center">
              <h1>Dream Heaven City</h1>
              <p>If you are looking at blank cassettes on the web Lorem ipsum dolor sit amet, consectetur adipisicing  eiusmod tempor incididunt.</p>
							<a class="btn btn--leftBorder btn--rightBorder" href="#/">Details</a>							
							<span class="hero__slideContent--right"></span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="hero__slide">
            <img src="<?php echo e(asset('vendor_app/sprash/img/hero-1.png')); ?>" alt="">
            <div class="hero__slideContent text-center">
              <h1>Dream Heaven City</h1>
              <p>If you are looking at blank cassettes on the web Lorem ipsum dolor sit amet, consectetur adipisicing  eiusmod tempor incididunt.</p>
							<a class="btn btn--leftBorder btn--rightBorder" href="#/">Details</a>
							<span class="hero__slideContent--right"></span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="hero__slide">
            <img src="<?php echo e(asset('vendor_app/sprash/img/hero-3.png')); ?>" alt="">
            <div class="hero__slideContent text-center">
              <h1>Dream Heaven City</h1>
              <p>If you are looking at blank cassettes on the web Lorem ipsum dolor sit amet, consectetur adipisicing  eiusmod tempor incididunt.</p>
							<a class="btn btn--leftBorder btn--rightBorder" href="#/">Details</a>							
							<span class="hero__slideContent--right"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>

	<section class="about section-margin mb-5">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-5">
					<div class="about__img text-center text-md-left mb-5 mb-md-0">
						<img class="img-fluid" src="<?php echo e(asset('vendor_app/sprash/img/about.png')); ?>" alt="">
						<a href="#/" class="about__img__date text-center">
							<h3>26</h3>
							<p>Years <br> of Creativity</p>
						</a>
					</div>
				</div>
				<div class="col-md-7 pl-xl-5">
					<div class="section-intro">
						<h4 class="section-intro__title">About our Company</h4>
						<h2 class="section-intro__subtitle">We've been creating <br> Awesome Since 1992</h2>
					</div>
					<p>If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam. Eiusmod tempor incididunt ut labore et dolore magna aliqua consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					<p>If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
					<a class="btn btn--rightBorder mt-4" href="#/">Read More</a>
				</div>
			</div>
		</div>
	</section>
	


	<section class="overview">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-lg-4 col-xl-3 mb-4 mb-xl-0">
					<div class="media align-items-center overview__single">
						<span class="overview__single__icon"><i class="ti-crown"></i></span>
						<div class="media-body">
							<h3>286+</h3>
							<p>Projects done</p>
						</div>
					</div>
				</div>

				<div class="col-sm-6 col-lg-4 col-xl-3 mb-4 mb-xl-0">
					<div class="media align-items-center overview__single">
						<span class="overview__single__icon"><i class="ti-face-smile"></i></span>
						<div class="media-body">
							<h3>942+</h3>
							<p>Happy Clients</p>
						</div>
					</div>
				</div>

				<div class="col-sm-6 col-lg-4 col-xl-3 mb-4 mb-xl-0">
					<div class="media align-items-center overview__single">
						<span class="overview__single__icon"><i class="ti-user"></i></span>
						<div class="media-body">
							<h3>263+</h3>
							<p>Real professionals</p>
						</div>
					</div>
				</div>

				<div class="col-sm-6 col-lg-4 col-xl-3 mb-4 mb-xl-0">
					<div class="media align-items-center overview__single">
						<span class="overview__single__icon"><i class="ti-gift"></i></span>
						<div class="media-body">
							<h3>2000+</h3>
							<p>Cups of Coffee</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
  

	<section class="portfolio section-margin">
		<div class="container">
			<div class="section-intro">
				<h4 class="section-intro__title">OUR PORTFOLIO</h4>
				<h2 class="section-intro__subtitle bottom-border">Latest Completed Projects</h2>
			</div>

			<div class="row align-items-end pb-md-5 mb-4">
				<div class="col-md-7 mb-4 mb-md-0">
					<div class="portfolio__img">
						<img class="img-fluid" src="<?php echo e(asset('vendor_app/sprash/img/portfolio1.png')); ?>" alt="">
					</div>
				</div>
				<div class="col-md-5 mb-5 pl-xl-5">
					<h4 class="section-intro__title left-border">December, 2018</h4>
					<h2 class="section-intro__subtitle small">Pure Bedroom Architecture</h2>
					<p>If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>

					<a class="btn btn--rightBorder mt-3" href="#/">Read More</a>
				</div>
			</div>

			<div class="row align-items-end pb-md-5 mb-4">
				<div class="col-md-5 mb-5 pr-xl-5 order-2 order-md-1">
					<h4 class="section-intro__title left-border">December, 2018</h4>
					<h2 class="section-intro__subtitle small">Pure Bedroom Architecture</h2>
					<p>If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>

					<a class="btn btn--rightBorder mt-3" href="#/">Read More</a>
				</div>
				<div class="col-md-7 mb-4 mb-md-0 order-1 order-md-2">
					<div class="portfolio__img">
						<img class="img-fluid" src="<?php echo e(asset('vendor_app/sprash/img/portfolio2.png')); ?>" alt="">
					</div>
				</div>
			</div>

			<div class="row align-items-end pb-md-5 mb-4">
				<div class="col-md-7 mb-4 mb-md-0">
					<div class="portfolio__img">
						<img class="img-fluid" src="<?php echo e(asset('vendor_app/sprash/img/portfolio3.png')); ?>" alt="">
					</div>
				</div>

				<div class="col-md-5 mb-5 pl-xl-5">
					<h4 class="section-intro__title left-border">December, 2018</h4>
					<h2 class="section-intro__subtitle small">Pure Bedroom Architecture</h2>
					<p>If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>

					<a class="btn btn--rightBorder mt-3" href="#/">Read More</a>
				</div>
			</div>

			<div class="row align-items-end pb-md-5 mb-4">
				<div class="col-md-5 mb-5 pr-xl-5 order-2 order-md-1">
					<h4 class="section-intro__title left-border">December, 2018</h4>
					<h2 class="section-intro__subtitle small">Pure Bedroom Architecture</h2>
					<p>If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>

					<a class="btn btn--rightBorder mt-3" href="#/">Read More</a>
				</div>

				<div class="col-md-7 order-1 order-md-2 mb-4 mb-md-0">
					<div class="portfolio__img">
						<img class="img-fluid" src="<?php echo e(asset('vendor_app/sprash/img/portfolio4.png')); ?>" alt="">
					</div>
				</div>
			</div>

			<div class="text-center pt-2">
				<button class="btn btn--rightBorder btn--leftBorder">Load More Projects</button>
			</div>
		</div>
	</section>
	

	<section class="tips tips-bg">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-7 mb-4 mb-lg-0">
					<h2 class="section-intro__subtitle">Get to Know Project Estimate?</h2>
					<p>There is a moment in the life of any aspiring astronomer that it is time to buy that first telescope. It’s exciting to think about setting up your own viewing station whether that is on the deck</p>
				</div>
				<div class="col-lg-5 text-center text-lg-right">
					<a class="btn btn-dark btn--leftBorder btn--rightBorder" href="#/">Get Estimate</a>
				</div>
			</div>
		</div>
	</section>

	<section class="testimonial section-margin">
		<div class="container">
			<div class="section-intro">
				<h4 class="section-intro__title">OUR Testimonial</h4>
				<h2 class="section-intro__subtitle bottom-border">What People Say About Us</h2>
			</div>

			<div class="owl-carousel owl-theme testimonialCarousel">
				<div class="item">
					<div class="media testimonial__slide">
						<img class="img-fluid mr-4" src="<?php echo e(asset('vendor_app/sprash/img/testimonial.png')); ?>" width="120" height="125" alt="">
						<div class="media-body">
							<blockquote>
								“If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt amet.”
							</blockquote>
							<h3>Falcon Astle</h3>
							<p>Google Android</p>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="media testimonial__slide">
						<img class="img-fluid mr-4" src="<?php echo e(asset('vendor_app/sprash/img/testimonial.png')); ?>" width="120" height="125" alt="">
						<div class="media-body">
							<blockquote>
								“If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt amet.”
							</blockquote>
							<h3>Falcon Astle</h3>
							<p>Google Android</p>
						</div>
					</div>
        </div>
        <div class="item">
					<div class="media testimonial__slide">
						<img class="img-fluid mr-4" src="<?php echo e(asset('vendor_app/sprash/img/testimonial.png')); ?>" width="120" height="125" alt="">
						<div class="media-body">
							<blockquote>
								“If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt amet.”
							</blockquote>
							<h3>Falcon Astle</h3>
							<p>Google Android</p>
						</div>
					</div>
        </div>
        <div class="item">
					<div class="media testimonial__slide">
						<img class="img-fluid mr-4" src="<?php echo e(asset('vendor_app/sprash/img/testimonial.png')); ?>" width="120" height="125" alt="">
						<div class="media-body">
							<blockquote>
								“If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt amet.”
							</blockquote>
							<h3>Falcon Astle</h3>
							<p>Google Android</p>
						</div>
					</div>
        </div>
        <div class="item">
					<div class="media testimonial__slide">
						<img class="img-fluid mr-4" src="<?php echo e(asset('vendor_app/sprash/img/testimonial.png')); ?>" width="120" height="125" alt="">
						<div class="media-body">
							<blockquote>
								“If you are looking at blank cassettes on the web lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt amet.”
							</blockquote>
							<h3>Falcon Astle</h3>
							<p>Google Android</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<footer class="footer footer-bg">
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-lg-2 mb-4 mb-lg-0 text-left">
					<h3 class="footer__title">Top Products</h3>
					<ul class="footer__link">
						<li><a href="#/">managed Website</a></li>
						<li><a href="#/">Manage Reputation</a></li>
						<li><a href="#/">power Tools</a></li>
						<li><a href="#/">Marketing Service</a></li>
					</ul>
				</div>
				<div class="col-sm-4 col-lg-2 mb-4 mb-lg-0 text-left">
					<h3 class="footer__title">Quick Links</h3>
					<ul class="footer__link">
						<li><a href="#/">Jobs</a></li>
						<li><a href="#/">Brand Assets</a></li>
						<li><a href="#/">Investor Relations</a></li>
						<li><a href="#/">Terms of Service</a></li>
					</ul>
				</div>
				<div class="col-sm-4 col-lg-2 mb-4 mb-lg-0 text-left">
					<h3 class="footer__title">Features</h3>
					<ul class="footer__link">
						<li><a href="#/">Jobs</a></li>
						<li><a href="#/">Brand Assets</a></li>
						<li><a href="#/">Investor Relations</a></li>
						<li><a href="#/">Terms of Service</a></li>
					</ul>
				</div>
				<div class="col-sm-4 col-lg-2 mb-4 mb-lg-0 text-left">
					<h3 class="footer__title">Resources</h3>
					<ul class="footer__link">
						<li><a href="#/">Guides</a></li>
						<li><a href="#/">Research</a></li>
						<li><a href="#/">Experts</a></li>
						<li><a href="#/">Agencies</a></li>
					</ul>
				</div>
				<div class="col-sm-8 col-lg-4 mb-4 mb-lg-0 text-left">
					<h3 class="footer__title">Newsletter</h3>
					<p>You can trust us. we only send promo offers,</p>
					<form action="" class="form-subscribe">
						<div class="input-group">
							<input type="email" class="form-control" placeholder="Your email address" required>
							<div class="input-group-append">
								<button class="btn-append" type="submit"><i class="lnr lnr-arrow-right"></i></button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<div class="d-sm-flex justify-content-between footer__bottom top-border">
				<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
				<ul class="social-icons mt-2 mt-sm-0">
					<li><a href="#/"><i class="fab fa-facebook-f"></i></a></li>
					<li><a href="#/"><i class="fab fa-twitter"></i></a></li>
					<li><a href="#/"><i class="fab fa-dribbble"></i></a></li>
					<li><a href="#/"><i class="fab fa-behance"></i></a></li>					
				</ul>
			</div>
		</div>
	</footer>



	<script src="<?php echo e(asset('vendor_app/sprash/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>	
	<script src="<?php echo e(asset('vendor_app/sprash/vendor/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor_app/sprash/vendor/owl-carousel/owl.carousel.min.js')); ?>"></script>

	<script>
		var testimonialCarousel = $('.testimonialCarousel');
      testimonialCarousel.owlCarousel({
      loop:true,
      margin:80,
      startPosition: 2,
      nav: false,
      responsiveClass:true,
      responsive:{
        0:{
            items:1
        },
        1000:{
            items:2,
            loop:true
        }
      }
    });

    var heroCarousel = $('.heroCarousel');
      heroCarousel.owlCarousel({
      loop:true,
      margin:10,
      nav: false,
      startPosition: 1,
      responsiveClass:true,
      responsive:{
        0:{
            items:1
        }
      }
	});

	var dropToggle = $('.menu_right > li').has('ul').children('a');
	dropToggle.on('click', function() {
		dropToggle.not(this).closest('li').find('ul').slideUp(200);
		$(this).closest('li').children('ul').slideToggle(200);
		return false;
	});

	$( ".toggle_icon" ).on('click', function() {
		$( 'body' ).toggleClass( "open" );
	});

	</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views\index.blade.php ENDPATH**/ ?>