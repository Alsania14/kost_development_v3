<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TIRTA ARUNA EMAIL</title>
    <style>
        .container{
            display:flex;
            flex-direction:column;
            width:auto;
            height:auto;
            border:3px solid black;
            overflow:auto;
        }

        .header {
            display:flex;
            flex-direction:column;
            width:auto;
            height:auto;
            font-size:20pt;
            text-align:center;
        }

        .body {
            display:flex;
            flex-direction:column;
            width:auto;
            height:auto;
            font-size:20pt;
        }

        .footer {
            display:flex;
            flex-direction:column;
            width:auto;
            height:auto;
            text-align:right;
            padding-right:100px;
        }

        table,th,td {
            border:3px solid black;
            text-align:center;
            overflow:auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>TIRTA ARUNA COTTAGE EMAIL</h1>
            <p>Jalan Banteng Nomor 16 Nomor HP :081246082357</p>
        </div>

        <div class="body">
            <table>
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Nama</th>
                        <th>Kamar</th>
                        <th>Tgl Awal Sewa</th>
                        <th>Tgl Akhir Sewa</th>
                        <th>deadline Pembayaran</th>
                        <th>Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>10000000000000</td>
                        <td>data</td>
                        <td>data</td>
                        <td>data</td>
                        <td>data</td>
                        <td>data</td>
                        <td>data</td>
                    </tr>
                </tbody>
            </table>
        </div>


        <div class="footer">
            <h6 style="margin-bottom:20px;">BIG REGRADS</h6>
            <h6>THE SYSTEM</h6>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/email/email_ujicoba.blade.php ENDPATH**/ ?>