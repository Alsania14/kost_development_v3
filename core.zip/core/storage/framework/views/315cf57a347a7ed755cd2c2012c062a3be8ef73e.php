
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('pembayaran',config('global.active')); ?>
<?php $__env->startSection('header','Pembayaran Kost \ Tagihan Anda'); ?>
<?php $__env->startSection('content'); ?>
<!-- AWAL CONTAINER -->
<div class="container-fluid p-0" style="min-height:550px;">
<p class="text-info">Hai <?php echo e($user->username); ?>, Jika belum memahami alur dan methode pembayaran, kamu dapat melihat halaman pedoman pembayaran pada menu pembayaran kost</p>
      <div class="table-responsive">
      <table class="table table-striped table-sm text-light" style="border-bottom:3px solid #e39414">
          <thead style="<?php echo e(config('global.active')); ?>">
            <tr>
              <th>Nomor</th>
              <th>Pembayaran</th>
              <th>Tanggal Sewa</th>
              <th>Harga</th>
              <th>Status Tagihan</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php 
                foreach ($tagihans as $index => $tagihan) {?>
                    <tr>
                        <td><?php echo e(($index+1)); ?></td>
                        <td style="min-width:100px;"><?php echo e('Kamar '.$tagihan->kamar()->nomor); ?></td>
                        <td style="min-width:250px;"><?php echo e($tagihan->tgl_awal_sewa.' s/d '.$tagihan->tgl_akhir_sewa); ?></td>
                        <td style="min-width:150px;"><?php echo e('Rp. '.number_format($tagihan->nominal_pembayaran,0,'.','.')); ?></td>
                        <td><?php echo e($tagihan->status_tagihan); ?></td>
                        <?php
                        if($tagihan->status_tagihan == 'hutang')
                        {?>
                            <td>
                                <a href="<?php echo e(url('/pilihpembayaran',[Crypt::encryptString($tagihan->id)])); ?>">
                                    <button class="btn btn-sm btn-info">Charge</button>
                                </a>
                            </td>
                        <?php
                        }
                        elseif($tagihan->status_tagihan == 'lunas')
                        {?>
                            <td>
                                <a>
                                    <button class="btn btn-sm btn-success">Struct</button>
                                </a>
                            </td>
                        <?php
                        }
                        ?>
                    </tr>
            <?php
                }
            ?>
          
          </tbody>
        </table>
        </div>

</div>
<!--  AKHIR CONTAINER -- -->
<footer class="row page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>

<?php $__env->startSection('judul','Charge Gagal'); ?>
<?php $__env->startSection('isi','Charge Berhasil Silahkan lanjutkan ke tahap selanjutnya'); ?>



<?php $__env->startSection('modal_denied_judul','Charge Gagal'); ?>
<?php $__env->startSection('modal_denied_isi','Mohon Maaf Charge gagal, kemungkinan sedang terjadi gangguan,  silahkan gunakan metode pembayaran yang lain atau hubungi developer'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal_denied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/user/pembayaran/tagihan/tagihan.blade.php ENDPATH**/ ?>