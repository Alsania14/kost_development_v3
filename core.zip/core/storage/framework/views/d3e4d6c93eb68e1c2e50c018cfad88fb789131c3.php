
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('pelaporan',config('global.active')); ?>
<?php $__env->startSection('header','Pelaporan'); ?>
<?php $__env->startSection('content'); ?>
<div class="jumbotron p-1 bg-dark" style="border-top:3px solid orange;">
    <div class="container">
        <div class="row">
            <div class="col d-flex flex-column justify-content-center text-center">
                <h3>LAPORAN KERUSAKAN PROPERTI</h3>
                <div class="overflow-hidden">
<?php
        if($kuota_laporan == 0)
        {
?>
                    <img src="<?php echo e(asset('storage/image_pelaporan/noimage.png')); ?>" class="mb-4" style="max-height:300px;" id="gambar">
                    <div class="d-flex flex-column justify-content-center">
                    <form action="<?php echo e(url('/laporan')); ?>" id="myform" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <label for="inputan" class="btn btn-info" style="width:200px;">MASUKKAN GAMBAR</label>
                        <input type="file" id="inputan" accept="image/*" name="laporan" style="display:none;">
                        <input type="submit" id="submit" style="display:none;">
                        </form>
                        </div>
                        <textarea name="keluhan" class="w-75 mt-3" form="myform" style="resize:none;color:black;border-radius:8px;border-top:3px solid orange;height:100px;" placeholder="Jelaskan kerusakan properti" maxlength="200"></textarea>
<?php   if($errors->has('keluhan'))
        {
?>
                        <p class="text-danger lead"><?php echo e($errors->first('keluhan')); ?></p>
<?php
        }
?>
                    <div>
                    <label for="submit" class="btn mt-5" style="<?php echo e(config('global.active')); ?>">SUBMIT</label>
                    </div>
                </div>
<?php
        }
        else
        {
?>  
                    <img src="<?php echo e(asset('storage/image_pelaporan/lock.png')); ?>" style="max-height:300px;">
                    <h5 class="text-info">KUOTA LAPORAN HARI INI TELAH DIGUNAKAN</h5>
                </div>
<?php
        }
?>
                
            </div>
        </div>
    </div>
</div>

<div class="jumbotron pt-5 bg-dark" style="border-top:3px solid orange;">
        <div class="container">
            <div class="row">
                <div class="col">
                <h3 class="text-center">HISTORY LAPORAN</h3>
<?php
        foreach ($laporans as $index => $laporan)
        {
?>       
                <div class="list-group mt-5">
                <div class="list-group-item list-group-item-action flex-column align-items-start bg-info shadow-lg">
                    <div class="d-flex w-100 justify-content-between">
                    <h5 class="mb-1">Laporan</h5>
                    <form action="<?php echo e(url('/delete')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="laporan_id" value="<?php echo e(Crypt::encryptString($laporan->id)); ?>">
                    <button type="submit" class="text-light btn btn-sm btn-danger">X</button>
                    </form>
                    </div>
                </div>
                <div class="list-group-item list-group-item-action flex-column align-items-start bg-dark shadow-lg">
                    <div class="d-flex w-100 justify-content-between">
                    </div>
                    <h5>LAPORAN ANDA</h5>
                    <small><?php echo e($laporan->created_at); ?></small>
                    <p class="mb-1"><?php echo e($laporan->keluhan); ?></p>
<?php
            if($laporan->image_keluhan != null)
            {
?>
                    <a href="<?php echo e(url('storage/image_pelaporan',[$laporan->image_keluhan])); ?>" class="btn btn-primary btn-sm mt-4" >GAMBAR</a>
<?php
            }
            else
            {
?>
                   <button class="btn btn-secondary btn-sm mt-4">TIDAK DISERTAKAN GAMBAR</button>
<?php
            }
?>
                    <h5 class="mb-1 mt-3">RESPON ADMIN</h5>
                    <p class="mb-1"><?php echo e($laporan->respon); ?></p>
                    
                    <h5 class="mb-1 mt-3">STATUS</h5>
                    <p class="mb-1"><?php echo e(strtoupper($laporan->status_keluhan)); ?></p>
                </div>
                </div>
<?php
        }
?>
                </div>
            </div>
        </div>
</div>

<?php
        if($kuota_laporan == 0)
        {  
?>
    <script>
        var image = document.getElementById('gambar');
        var input = document.getElementById('inputan');
        input.addEventListener('change',(ev)=>{
                console.log(input.files[0]);
                if(input.files[0].type.indexOf("image/") > -1){
                    image.src = window.URL.createObjectURL(input.files[0]);
                    image.innerHtml = window.URL.createObjectURL(input.files[0]);
                }
            })
    </script>
<?php
        }
?>

<?php $__env->startSection('judul','LAPORAN BERHASIL'); ?>
<?php $__env->startSection('isi','Terimakasih sudah melaporkan keluhan anda, dimohon untuk menunggu balasan dari admin ya, saat ada balasan sistem akan memberikan email kepada anda'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/user/pelaporan/pelaporan.blade.php ENDPATH**/ ?>