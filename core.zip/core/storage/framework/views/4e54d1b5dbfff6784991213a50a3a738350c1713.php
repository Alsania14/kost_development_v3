
<?php $__env->startSection('content'); ?>
<h4>SUBJECT : TAGIHAN KAMAR KOST</h4>
<h4>Hai <?php echo e($data['name']); ?>,</h4>
<p>Tagihan sewa kamar kost anda dengan kamar nomor <?php echo e($data['kamar']); ?> dan tanggal sewa <?php echo e($data['tgl_awal']); ?> s/d <?php echo e($data['tgl_akhir']); ?> telah dibentuk silahkan untuk segera melakukan pembayaran sebelum batas pembayaran pada tanggal <b><?php echo e($data['deadline']); ?> </b>, pembayaran dapat dilakukan melalui sistem dengan beberapa metode pembayaran berikut ini</p>
<ul>
    <li>BNI BANK TRANSFER</li>
    <li>BCA BANK TRANSFER</li>
    <li>MANDIRI BANK TRANSFER</li>
    <li>PERMATA BANK TRANSFER</li>
    <li>INDOMARET MINIMARKET PAYMENT</li>
    <li>INDOMARET MINIMARKET PAYMENT</li>
    <li>MANUAL PAYMENT</li>
</ul>
<p>dimohon untuk segera melakukan pembayaran dengan metode yang telah disediakan diatas, untuk info lebih lanjut bisa dilihat di aplikasi, terimakasih :)</p>

<p><b>BIG REGRADS</b></p><br><br>
<p><b>THE SYSTEM</b></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('email/email_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/email/NotifUser.blade.php ENDPATH**/ ?>