
<?php $__env->startSection('pembuka'); ?>
Hai <?php echo e($data['name']); ?> Tagihan sewa kamar kost anda dengan kamar nomor <?php echo e($data['kamar']); ?> dan tanggal sewa <?php echo e($data['tgl_awal']); ?> s/d <?php echo e($data['tgl_akhir']); ?> telah dibentuk dengan nominal <?php echo e('Rp '.number_format($data['harga'],0,'.','.')); ?> silahkan untuk segera melakukan pembayaran sebelum batas pembayaran pada tanggal <b><?php echo e($data['deadline']); ?> </b>, pembayaran dapat dilakukan melalui sistem dengan beberapa metode pembayaran berikut ini
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>
<tr>
    <td colspan="7" style="border:none;">
        <ul style="text-align:left;">
            <li>BNI BANK TRANSFER</li>
            <li>BCA BANK TRANSFER</li>
            <li>MANDIRI BANK TRANSFER</li>
            <li>PERMATA BANK TRANSFER</li>
            <li>INDOMARET MINIMARKET PAYMENT</li>
            <li>ALFAMART MINIMARKET PAYMENT</li>
            <li>MANUAL PAYMENT</li>
        </ul>
    </td>
</tr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('penutup'); ?>
Dimohon untuk user segera melakukan pembayaran, apabila melewati waktu yang telah ditentukan maka sistem akan memblokir akses pengguna dan dianggap tidak melankutkan sewa. Sekian dari system terimakasih atas perhatiannya, have a good day
<?php $__env->stopSection(); ?>
<?php echo $__env->make('email.email_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/email/NotifUser.blade.php ENDPATH**/ ?>