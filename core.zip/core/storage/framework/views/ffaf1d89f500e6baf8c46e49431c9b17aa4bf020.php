
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('kamar',config('global.active')); ?>
<?php $__env->startSection('header','Kamar'); ?>
<?php $__env->startSection('content'); ?>

<!-- AWAL CONTAINER -->
<div class="container-fluid p-0">
    <div class="row">
        <div class="col">
            <div class="jumbotron m-0 text-center bg-dark d-flex justify-content-around flex-wrap" style="border-top: 3px solid orange;">
<?php
            foreach ($kamar_all as $index => $kamar_single)
            {
?>
            <div class="card mt-3" style="max-width:330px;background:#FEE6A8;">
            <img class="card-img-top" src="<?php echo e(asset('storage\kamar\kamar_1.jpg')); ?>" alt="Card image cap" style="max-height:150px;opacity:1;" >
            <div class="card-body">
                <h5 class="card-title m-0 text-dark">KAMAR</h5>
                <h1 class="card-title m-0 text-dark" style="font-size:40pt;"><?php echo e($kamar_single->nomor); ?></h1>
                <h5 class="card-title m-0 mt-2 text-dark">FASILITAS</h5>
                <p class="card-text m-0 text-dark"><?php echo e($kamar_single->fasilitas); ?></p>
                <h5 class="card-title m-0 mt-2 text-dark">STATUS</h5>
<?php
                if($kamar_single->user_id != null)
                {
?>
                <p class="card-text m-0 badge badge-success mt-2" style="font-size:12pt;">TERISI</p>
<?php
                }
                else
                {
?>
                <p class="card-text m-0 badge badge-danger mt-2" style="font-size:12pt;">KOSONG</p>
<?php
                }
?>
                <h5 class="card-title m-0 mt-2 text-dark">HARGA</h5>
                <p class="card-text text-dark">Rp. <?php echo e(number_format($kamar_single->harga,0,'.','.')); ?>/<?php echo e($kamar_single->tipe_pembayaran); ?></p>
                <a href="<?php echo e(url('/kamar',[Crypt::encryptString($kamar_single->id)])); ?>" class="btn btn-info">GAMBAR</a>
            </div>
            </div>
<?php
                }
?>
            </div>
        </div>
    </div>
</div>
<!-- AKHIR CONTAINER -->
<footer class="page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/user/kamar/kamar.blade.php ENDPATH**/ ?>