
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('notifikasi',config('global.active')); ?>
<?php $__env->startSection('header','Notifikasi'); ?>
<?php $__env->startSection('content'); ?>
<!-- AWAL CONTAINER -->
<div class="container-fluid p-0" style="min-height:550px;">
<form action="<?php echo e(url('/markall',[Crypt::encryptString($user->id)])); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PATCH')); ?>

<button type="submit" class="btn btn-info mb-3">Mark as Read All</button>
</form>
<?php
    
    if(!($notif_model->all() == null))
    {
    foreach ($notif_model as $index => $notif) { ?>        
    
        <div class="list-group">
        <div class="list-group-item list-group-item-action flex-column align-items-start bg-dark"
            <?php
                if($notif->full_data->type == 'special')
                {
                    echo 'style="'.config('global.active').'"';
                }
            ?>
        >
            <div class="d-flex w-100 justify-content-between">
            <h5 class="mb-1"><?php echo e($notif->full_data->title); ?></h5>
            <small class="text-right"><?php echo e($notif->created_at); ?></small>
            </div>
            <p class="mb-4"><?php echo e($notif->full_data->text); ?>.</p>
            <small class="mt-3">System Tirta Aruna Cottage</small>
        </div>
        </div>

<?php    }
    }
    else
    {?>
        <div class="row d-flex justify-content-center">
            <div class="col-md text-center">
                <img class="img" src="<?php echo e(asset('vendor_app/img_web/no_notifikasi.png')); ?>" style="max-height:400px;" alt="">
            </div>
        </div>
<?php
    }
?>
<!-- footer -->
</div>
<footer class="row page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>
<!-- AKHIR CONTAINER -->

<?php $__env->startSection('judul','Mark All Berhasil'); ?>
<?php $__env->startSection('isi','Mark All Berhasil Dilakukan'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/user/notifikasi/notifikasi.blade.php ENDPATH**/ ?>