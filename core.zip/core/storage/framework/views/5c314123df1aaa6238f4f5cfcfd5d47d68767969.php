
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('pembayaran',config('global.active')); ?>
<?php $__env->startSection('header','Pembayaran Kost \ Tagihan Anda \ Arsip Tagihan'); ?>
<?php $__env->startSection('content'); ?>
<!-- AWAL CONTAINER -->
<div class="container-fluid p-0" style="min-height:550px;">
<div class="row m-0 justify-content-end">
    <div class="btn-group" role="group" aria-label="Basic example">
      <a href="<?php echo e(url('/tagihan')); ?>" type="button" class="btn btn-primary">Kembali</a>
    </div>
  </div>
<p class="text-info">Hai <?php echo e($user->username); ?>, Berikut ini merupakan arsip dari tagihan sebelumnya</p>
      <div class="table-responsive">
      <table class="table table-striped table-sm text-light" style="border-bottom:3px solid rgb(58,83,180);">
          <thead style="<?php echo e(config('global.arsip')); ?>">
            <tr>
              <th>Nomor</th>
              <th>Pembayaran</th>
              <th>Tanggal Sewa</th>
              <th>Harga</th>
              <th>Status Tagihan</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
<?php 
                foreach ($tagihans as $index => $tagihan) 
                {
                  $encrypt = Crypt::encryptString($tagihan->id);
?>
                    <tr>
                        <td><?php echo e(($index+1)); ?></td>
                        <td style="min-width:100px;"><?php echo e('Kamar '.$tagihan->kamar()->nomor); ?></td>
                        <td style="min-width:250px;"><?php echo e($tagihan->tgl_awal_sewa.' s/d '.$tagihan->tgl_akhir_sewa); ?></td>
                        <td style="min-width:150px;"><?php echo e('Rp. '.number_format($tagihan->nominal_pembayaran,0,'.','.')); ?></td>
                        <td><?php echo e($tagihan->status_tagihan); ?></td>
                            <td>
                                <a>
                                    <button class="btn btn-sm btn-success" style="display:inline-block;">Struct</button>
                                </a>
                                
                                <form action="<?php echo e(url('/keluarkanarsiptagihan',[$encrypt])); ?>" class="m-0" style="display:inline-block;" method="POST">
                                  <?php echo e(csrf_field()); ?>

                                  <?php echo e(method_field('put')); ?>

                                  <input class="btn-sm btn-danger" type="submit" value="Keluarkan arsip">
                                </form>
                            </td>
                    </tr>
<?php
                }
?>
          
          </tbody>
        </table>
        </div>

</div>
<!--  AKHIR CONTAINER -- -->
<footer class="row page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views//user/pembayaran/transaksi/arsiptagihan.blade.php ENDPATH**/ ?>