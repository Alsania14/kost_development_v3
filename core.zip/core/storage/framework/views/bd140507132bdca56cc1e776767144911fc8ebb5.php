
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('profile',config('global.active')); ?>
<?php $__env->startSection('header','Report User \ Validasi Transaksi User'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
    <div class="jumbotron bg-dark" id="searchengine" style="border-top:3px solid orange;overflow:hidden;max-height:1000px;">
    <div class="row">
        <div class="col-md">
            <h3 class="text-center mb-5">TRANSAKSI MANUAL</h3>
            <div class="table-responsive">
                <table class="table table-striped table-sm text-light" style="border-bottom:3px solid #e39414">
                    <thead style="<?php echo e(config('global.active')); ?>">
                        <tr>
                        <th>Nomor</th>
                        <th style="min-width:120px;">Username</th>
                        <th style="min-width:100px;">Tagihan ID</th>
                        <th style="min-width:200px;">Nominal Pembayaran</th>
                        <th style="min-width:200px;">Order ID</th>
                        <th style="min-width:100px;">Kamar</th>
                        <th style="min-width:250px;">Tanggal Pembayaran</th>
                        <th style="min-width:100px;">Tipe</th>
                        <th style="min-width:100px;">Status Transaksi</th>
                        <th style="min-width:200px;">Bukti Transaksi</th>
                        <th style="min-width:250px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
<?php
                    foreach ($transaksis as $index => $transaksi)
                    {
                        $id = Crypt::encryptString($transaksi->id);
                        if(isset($_GET['page']))
                        {
                            if($_GET['page'] > 1 )
                            {
                                $index += (($_GET['page'] - 1) * 10) + 1;
                
                            }
                            else
                            {
                                $index+=1;
                            }    
                        }
                        else
                        {
                            $index+=1;
                        }
?>
                        <tr>
                            <td><?php echo e($index); ?></td>
                            <td><?php echo e($transaksi->username); ?></td>
                            <td><?php echo e($transaksi->tagihan_id); ?></td>
                            <td><?php echo e('Rp. '.number_format($transaksi->nominal_pembayaran,0,'.','.')); ?></td>
                            <td><?php echo e($transaksi->order_id); ?></td>
                            <td><?php echo e('Kamar '.$transaksi->nomor_kamar); ?></td>
                            <td><?php echo $transaksi->tgl_awal.'<b> S/D </b>'.$transaksi->tgl_akir; ?></td>
                            <td><?php echo e($transaksi->tipe_pembayaran); ?></td>
                            <td><?php echo e($transaksi->status_pembayaran); ?></td>
<?php
                        if($transaksi->bukti_transaksi != null)
                        {
?>
                            <td>
                                <a style="min-width:200px;" href="<?php echo e(url('/storage/bukti_pembayaran',[$transaksi->bukti_transaksi])); ?>" class="btn btn-info btn-sm">BUKTI PEMBAYARAN</a>
                            </td>
<?php
                        }
                        else
                        {
?>  
                            <td>
                                <a class="btn btn-secondary btn-sm" style="min-width:200px;">TIDAK ADA PEMBAYARAN</a>
                            </td>
<?php
                        }
                        if($transaksi->status_pembayaran == 'pending')
                        {
?>
                        <td >
                            <label onclick="peringatan(<?php echo e($index); ?>)" style="width:100px;" class="btn btn-success btn-sm">VERIFIKASI</label>
                            <form action="<?php echo e(url('/adminverifikasitransaksi',[$id])); ?>" method="POST" id="form_<?php echo e($index); ?>" style="display:none;">
                                <?php echo e(csrf_field()); ?>

                            </form>

                            <a href="https://api.whatsapp.com/send?phone=6281246082357" target="_blank">
                                <label class="btn-sm btn btn-primary">WA USER</label>
                            </a>

                            <label onclick="peringatan2(<?php echo e($index); ?>)" style="width:100px;" class="btn btn-danger btn-sm">REJECT</label>
                            <form action="<?php echo e(url('/adminrejecttransaksi',[$id])); ?>" method="POST" id="form_reject_<?php echo e($index); ?>" style="display:none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </td>
                        

<?php
                        }
                        else
                        {
?>
                        <td>
                            <label class="btn btn-secondary btn-sm" style="width:100px;">VERIFIKASI</label>
                            <a href="" >
                                <label class="btn-sm btn btn-primary">WA USER</label>
                            </a>
                            <label onclick="peringatan2(<?php echo e($index); ?>)" style="width:100px;" class="btn btn-danger btn-sm">REJECT</label>
                            <form action="<?php echo e(url('/adminrejecttransaksi',[$id])); ?>" method="POST" id="form_reject_<?php echo e($index); ?>" style="display:none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </td>
                        
<?php
                        }
                    }
?>                  
                        </tr>
                    </tbody>
            </div>
        </div>
    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('judul','PERINGATAN ADMIN'); ?>
<?php $__env->startSection('isi'); ?>
<p class="text-dark"><b class="text-dark">SALAM ADMIN,</b> <br> Berikut ini merupakan peringatan efek apa yang akan terjadi pada sistem apabila admin melakukan VERIFIKASI atau REJECT.</p>
<p class="text-dark"><b class="text-dark">VERIFIKASI</b>
    <ul>
        <li class="text-dark">Lakukan <b class="text-dark">TRIPLE CHECKS</b> sebelum memverifikasi berkas user. Pertama lihat berkas yang dikirimkan oleh user, kedua tanyakan user apakah benar sudah mengirim bukti pembayaran dan yang terakhir cek saldo atau rekening admin sendiri</li>
        <li class="text-dark" class="text-dark">TRANSAKSI MANUAL yang telah diverifikasi oleh admin akan dinyatakan <b class="text-dark">SELESAI</b> oleh sistem dan tidak dapat dirubah kembali status pembayarannya,jadi pastikan uang yang dikirimkan users benar-benar sudah masuk ke dalam rekening admin</li>
        <li class="text-dark">Apabila Terjadi keanehan dan uang tidak masuk ke dalam rekening admin dimohon untuk berkomunikasi dengan users sebelum mereject transaksi</li>
        <li class="text-dark"> 
            Bila menemukan BUG tolong melapor
        </li>
    </ul>
<p class="text-dark"><b class="text-dark">TERIMAKASI ADMIN,</b> <br> Demi keamanan, untuk melanjutkan tindakan ini admin diharuskan memasukkan password aktif admin</p>
    <div class="d-flex flex-column">
    <h5 class="text-bold text-dark">PASSWORD</h5>
    <input type="password" class="form-controll text-dark" id="modal_lanjutkan_1" placeholder="PASSWORD ADMIN" form="" name="password" required>
    <input type="submit" id="modal_lanjutkan_2" class="btn-info btn mt-3" value="LANJUTKAN" style="position:relative;transform:translateX(-50%);left:50%;" form="">
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal_denied_judul','GAGAL'); ?>
<?php $__env->startSection('modal_denied_isi'); ?>
<p class="text-dark"><b class="text-dark">SALAM ADMIN,</b> <br> Berikut ini merupakan peringatan efek apa yang akan terjadi pada sistem apabila admin melakukan VERIFIKASI atau REJECT.</p>
<p class="text-dark"><b class="text-dark">VERIFIKASI</b>
    <ul>
        <li class="text-dark">Lakukan <b class="text-dark">TRIPLE CHECKS</b> sebelum memverifikasi berkas user. Pertama lihat berkas yang dikirimkan oleh user, kedua tanyakan user apakah benar sudah mengirim bukti pembayaran dan yang terakhir cek saldo atau rekening admin sendiri</li>
        <li class="text-dark" class="text-dark">TRANSAKSI MANUAL yang telah diverifikasi oleh admin akan dinyatakan <b class="text-dark">SELESAI</b> oleh sistem dan tidak dapat dirubah kembali status pembayarannya,jadi pastikan uang yang dikirimkan users benar-benar sudah masuk ke dalam rekening admin</li>
        <li class="text-dark">Apabila Terjadi keanehan dan uang tidak masuk ke dalam rekening admin dimohon untuk berkomunikasi dengan users sebelum mereject transaksi</li>
        <li class="text-dark"> 
            Bila menemukan BUG tolong melapor
        </li>
    </ul>
<p class="text-dark"><b class="text-dark">TERIMAKASI ADMIN,</b> <br> Demi keamanan, untuk melanjutkan tindakan ini admin diharuskan memasukkan password aktif admin</p>
    <div class="d-flex flex-column">
    <h5 class="text-bold text-dark">PASSWORD</h5>
    <input type="password" class="form-controll text-dark" id="modal_peringatan_1" placeholder="PASSWORD ADMIN" form="" name="password" required>
    <input type="submit" id="modal_peringatan_2" class="btn-info btn mt-3" value="LANJUTKAN" style="position:relative;transform:translateX(-50%);left:50%;" form="">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tambahanbawah'); ?>
<script>
    function peringatan(id)
    {
        $('#modal_lanjutkan_1').attr('form', 'form_'+id);
        $('#modal_lanjutkan_2').attr('form', 'form_'+id);
        $('#modal').modal('show');
        
    }

    function peringatan2(id)
    {
        $('#modal_peringatan_1').attr('form', 'form_reject_'+id);
        $('#modal_peringatan_2').attr('form', 'form_reject_'+id);
        $('#modaldenied').modal('show');
        
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app_layout/modal_denied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout.admindashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/admin\adminreportuser\validasitransaksi\validasitransaksi.blade.php ENDPATH**/ ?>