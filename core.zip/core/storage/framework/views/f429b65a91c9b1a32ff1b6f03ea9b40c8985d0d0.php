
<?php $__env->startSection('username',strtoupper($user->username)); ?>
<?php $__env->startSection('room',$kamar->nomor); ?>
<?php $__env->startSection('jumlah',$notification); ?>
<?php $__env->startSection('img_user',url('/storage/image_users',[$user->image])); ?>
<?php $__env->startSection('pembayaran',config('global.active')); ?>
<?php $__env->startSection('header','Pembayaran Kost \ Tagihan Anda \ Pilih Pembayaran \ Charge Success'); ?>
<?php $__env->startSection('content'); ?>
<!-- AWAL CONTAINER -->
<div class="container-fluid p-0" style="min-height:550px;">

    <div class="jumbotron bg-dark pt-4" style="border-top:3px solid orange;">
    <h1 class="display-4 mb-5">Charge Success</h1>
    <span style="font-family:courier new;">
    <p class="lead border-top border-bottom text-center">
       ONLINE VIRTUAL ACCOUNT PAYMENT</p>
    <p style="font-size:15pt;">
    <b>SUBJECT NOTA</b><br>
    ORDER ID : <br> <?php echo e($transaksi->order_id); ?> <br><br>
    DATE : <br> <?php echo e($transaksi->created_at); ?> <br><br>
    DIBERIKAN UNTUK : <br> <?php echo e($user->name); ?> <br><br>

    <b>PAYMENT METHOD</b><br>
    ONLINE PAYMENT BANK TRANSFER : <br> virtual account bank <?php echo e($transaksi->integration_name); ?> <br><br>

    <b>RANGKUMAN PEMBAYARAN</b><br>
    KAMAR NOMOR <?php echo e($nomor); ?> <br> QTY 1 <br> TANGGAL SEWA <?php echo e($transaksi->tgl_awal); ?> S/D <?php echo e($transaksi->tgl_akir); ?> <br>
    HARGA <?php echo e('Rp. '.number_format($transaksi->nominal,0,'.','.')); ?>

    <br><br>
    TOTAL <?php echo e('Rp. '.number_format($transaksi->nominal,0,'.','.')); ?> <br><br>
    
<?php
        if($transaksi->integration_name != 'mandiri')
        {
?>
            <div class="border-top border-bottom" style="font-size:20pt;">
                <b>VIRTUAL ACCOUNT</b><br>
                VIRTUAL ACCOUNT : <?php echo e($transaksi->field_1); ?>

            </div>
<?php
        }
        else
        {
?>
            <div class="border-top border-bottom" style="font-size:20pt;">
                <b>BILL CODE</b><br>
                BILL KEY : <?php echo e($transaksi->field_1); ?> <br>
                BILLER CODE : <?php echo e($transaksi->field_2); ?>

            </div>
<?php
        }
?>
    

    </p>
    <hr class="my-4">
    </span>
    <p class="text-light">Charge pembayaran kost berhasil dilakukan, silahkan lanjutkan untuk melakukan pembayaran menggunakan nomor VA diatas. Anda bebas untuk meninggalkan halaman ini, informasi diatas dapat anda lihat kembali pada halaman pembayaran kost -> transaksi</p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="<?php echo e(url('/transaksi')); ?>" role="button">Halaman Transaksi</a>
    </p>
    </div>

</div>
<!--  AKHIR CONTAINER -- -->
<footer class="row page-footer w-100 m-0 pt-4">
      <div class="col-md text-center text-dark" style="<?php echo e(config('global.active')); ?>">Team IT Tirta Aruna Cottage</div>
</footer>

<?php $__env->startSection('judul','Charge Berhasil'); ?>
<?php $__env->startSection('isi','Charge Berhasil Silahkan lanjutkan ke tahap selanjutnya'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views//user/pembayaran/transaksi/detailonline.blade.php ENDPATH**/ ?>