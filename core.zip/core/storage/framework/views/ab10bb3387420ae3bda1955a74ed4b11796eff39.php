
<?php $__env->startSection('pembuka'); ?>
Salam Admin, Berikut ini merupakan laporan dari sistem. Sistem telah mengirimkan tagihan kepada user kost dengan rincian sebagai berikut
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>
<tr>
            <th>Nomor</th>
            <th>Nama</th>
            <th>Kamar</th>
            <th>Tgl Awal Sewa</th>
            <th>Tgl Akhir Sewa</th>
            <th>deadline Pembayaran</th>
            <th>Harga</th>
        </tr>
<?php
    foreach ($sukses as $index => $data) {
?>
    <tr>
        <td><?php echo e($index+1); ?></td>
        <td><?php echo e($data['name']); ?></td>
        <td><?php echo e($data['kamar']); ?></td>
        <td><?php echo e($data['tgl_awal']); ?></td>
        <td><?php echo e($data['tgl_akhir']); ?></td>
        <td><?php echo e($data['deadline']); ?></td>
        <td><?php echo e('Rp. '.number_format($data['harga'],0,'.','.')); ?></td>
    </tr>
<?php
  }
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('penutup'); ?>
Terimakasih Atas perhatian admin semoga sukses :)
<?php $__env->stopSection(); ?>
<?php echo $__env->make('email.email_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/email/NotifAdmin.blade.php ENDPATH**/ ?>