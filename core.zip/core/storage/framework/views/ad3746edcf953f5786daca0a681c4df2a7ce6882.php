

<?php $__env->startSection('judul','LOGIN'); ?>
<?php $__env->startSection('keterangan','LOGIN SISTEM TIRTA ARUNA COTTAGE'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-center">
    <form action="<?php echo e(url('/login')); ?>" method="POST" class="w-50">
        <?php echo e(csrf_field()); ?>

        <h2 class="mt-3 text-left text-light">INPUT CREDENTIALS</h2>
        
        <input type="text" class="form-control mt-2" placeholder="username" name="username" required minlength="4" maxlength="50" value="<?php echo e(old('username')); ?>" autocorrect="off" autocapitalize="none">
        <p class="text-danger text-center">
            <?php
                if($errors->has('username')){
                    echo $errors->first('username');
                }
            ?>
        </p>
        
        <input type="password" class="form-control mt-2" placeholder="password" name="password" required minlength="4" maxlength="50" value="<?php echo e(old('password')); ?>" autocorrect="off" autocapitalize="none">
        <p class="text-danger text-center">
            <?php
                $system = Session::get('system');
                
                if($errors->has('username')){
                    echo '<p class="text-danger text-center">'.$errors->first('username').'</p>';
                }

                if($system == 'false')
                {
                    echo '<p class="text-danger text-center">Username atau Password salah</p>';
                }
            ?>
        </p>
      
        <div class="w-100 d-flex justify-content-center">
            <button class="btn-info bg-dark mt-5 mb-3 w-50 text-center" style="outline:none;max-width:200px;">SUBMIT</button>
        </div>
    </form>
    </div>

<!-- MODAL SUCCESS -->
    
    <?php $__env->startSection('judul','REGISTRASI BERHASIL'); ?>
    <?php $__env->startSection('isi','Anda dapat login ke dalam sistem setelah akun diverifikasi admin'); ?>

<!-- MODAL DENIED -->
    
    <?php $__env->startSection('modal_denied_judul','ACCESS DENIED'); ?>
    <?php $__env->startSection('modal_denied_isi','Akses anda ditolah oleh sistem'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app_layout/modal_denied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app_layout/reglog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v2\resources\views/user/reglog/login.blade.php ENDPATH**/ ?>