
<?php $__env->startSection('pembuka'); ?>
Hai <?php echo e($data['name']); ?>, <br>
Berikut ini merupakan link untuk melakukan verifikasi email anda, apabila email tidak diverifikasi dengan benar maka fitur sistem tidak dapat digunakan secara menyeluruh
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>
<a href="<?php echo e(url('/verifikasi',[$data['param']])); ?>">VERIFIKASI EMAIL ANDA</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('penutup','Terimakasih atas waktu dan perhatian anda'); ?>
<?php echo $__env->make('email/email_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/email/VerifikasiUser.blade.php ENDPATH**/ ?>