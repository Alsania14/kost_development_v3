
<?php $__env->startSection('content'); ?>
<h4>SUBJECT : TAGIHAN KAMAR KOST</h4>
<h4>Hai <?php echo e($data['name']); ?>,</h4>
<p>Berikut ini merupakan link untuk melakukan verifikasi email anda, apabila email tidak diverifikasi dengan benar maka fitur sistem tidak dapat digunakan secara menyeluruh</p>

<a href="<?php echo e(url('/verifikasi',[$data['param']])); ?>">VERIFIKASI EMAIL ANDA</a>

<p>Verifikasi harus dilakukan supaya anda dapat menggunakan fitur sistem secara keseluruhan, terimakasih atas waktunya</p>

<p><b>BIG REGRADS</b></p><br><br>
<p><b>THE SYSTEM</b></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('email/email_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kost_development_v3\core\resources\views/email/VerifikasiUser.blade.php ENDPATH**/ ?>