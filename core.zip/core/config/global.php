<?php

return [
    'active' => 'background: linear-gradient(90deg, rgba(245,131,0,1) 3%, rgba(243,181,36,1) 43%);',
    
    'timezone' => "Asia/Makassar",
    
    'nota' => 'TAC-ALPHA-',

    'url_midtrans' => "https://api.sandbox.midtrans.com/v2/charge",
    'key_midtrans' => "Basic U0ItTWlkLXNlcnZlci0wOExVLU5INEtwTGxRNGVrNXA4X29HNHo=",
];