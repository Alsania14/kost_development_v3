<?php

return [
    'active' => 'background: linear-gradient(90deg, rgba(245,131,0,1) 3%, rgba(243,181,36,1) 43%);',
];