<?php

return [
    'active' => 'background: linear-gradient(90deg, rgba(245,131,0,1) 3%, rgba(243,181,36,1) 43%);',
    'arsip' => 'background: linear-gradient(90deg, rgba(58,83,180,1) 0%, rgba(29,109,253,1) 50%, rgba(110,145,217,1) 100%);',

    'timezone' => "Asia/Makassar",
    
    'nota' => 'TAC-ALPHA-II-',

    'url_midtrans' => "https://api.sandbox.midtrans.com/v2/charge",
    'url_midtrans_base' => 'https://api.sandbox.midtrans.com/v2/', 
    'key_midtrans' => "Basic U0ItTWlkLXNlcnZlci0wOExVLU5INEtwTGxRNGVrNXA4X29HNHo=",
];