<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TIRTA ARUNA COTTAGE</title>
    <link href="{{ asset('vendor_app/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">

</head>
<body>
    <div class="container">
        <div class="jumbotron">
            <h1 class="text-success">SUKSES VERIFIKASI EMAIL</h1>
            <p>APABILA AKUN SUDAH DIVERIFIKASI OLEH ADMIN, SILAHKAN UNTUK LOGIN KEMBALI</p>
        </div>
    </div>
</body>
</html>